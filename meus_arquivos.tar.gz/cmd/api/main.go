package main

import (
	"integracao-fornecedor/internal/config"
	"integracao-fornecedor/internal/database"
	"integracao-fornecedor/internal/router"
	"log/slog"
	"os"

	_ "integracao-fornecedor/docs"
)

// @title           API de Integração Fornecedor
// @version         1.0
// @description     Esta é a API para integração de arquivos com fornecedores.
// @termsOfService  http://swagger.io/terms/

// @contact.name   API Support
// @contact.url    http://www.swagger.io/support
// @contact.email  support@swagger.io

// @license.name  Apache 2.0
// @license.url   http://www.apache.org/licenses/LICENSE-2.0.html

// @host      localhost:8080
// @BasePath  /
func main() {
	logger := slog.New(slog.NewJSONHandler(os.Stdout, nil))
	slog.SetDefault(logger)

	cfg, err := config.LoadConfig(".")
	if err != nil {
		slog.Error("ERRO: não foi possível carregar as configurações", "error", err)
		os.Exit(1)
	}

	db, err := database.InitDatabase(cfg)
	if err != nil {
		slog.Error("ERRO: não foi possível inicializar o banco de dados", "error", err)
		os.Exit(1)
	}

	r := router.SetupRouter(db)

	slog.Info("Servidor iniciado", "porta", cfg.APIPort)
	if err := r.Run(":" + cfg.APIPort); err != nil {
		slog.Error("ERRO: falha ao iniciar o servidor", "error", err)
		os.Exit(1)
	}
}
