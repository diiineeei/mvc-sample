package config

import (
	"github.com/joho/godotenv"
	"os"
)

// Config armazena todas as configurações da aplicação.
type Config struct {
	APIPort    string
	DBHost     string
	DBPort     string
	DBUser     string
	DBPassword string
	DBName     string
}

// LoadConfig lê as configurações de um arquivo .env no caminho especificado.
func LoadConfig(path string) (*Config, error) {
	if err := godotenv.Load(path + "/.env"); err != nil {
		return nil, err
	}

	return &Config{
		APIPort:    os.Getenv("API_PORT"),
		DBHost:     os.Getenv("DB_HOST"),
		DBPort:     os.Getenv("DB_PORT"),
		DBUser:     os.Getenv("DB_USER"),
		DBPassword: os.Getenv("DB_PASSWORD"),
		DBName:     os.Getenv("DB_NAME"),
	}, nil
}