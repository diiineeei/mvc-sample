package model

import "time"

type Batch struct {
	ID           uint       `gorm:"primaryKey;autoIncrement"`
	Name         string     `gorm:"type:varchar(500);not null"`
	ExternalID   *string    `gorm:"type:varchar(255)"`
	CreatedAt    time.Time  `gorm:"not null"`
	Type         string     `gorm:"type:varchar(255);not null"`
	UpdatedAt    *time.Time
	Status       *string    `gorm:"type:varchar(255)"`
	DeliveredAt  *time.Time
	Description  *string    `gorm:"type:varchar(500)"`
	DateCIF      *time.Time `gorm:"type:date"`
	DatePrinting *time.Time
	ReleaseDate  *time.Time
	ShippingDate *time.Time
	Registers    []Register `gorm:"foreignKey:FileID"` // Relação: Um Batch tem muitos Registers
}

func (Batch) TableName() string {
	return "batch"
}