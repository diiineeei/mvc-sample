package model

type Delivery struct {
	ID         uint    `gorm:"primaryKey;autoIncrement"`
	Address    *string `gorm:"type:varchar(500)"`
	RegisterID uint    `gorm:"not null;unique"` // Chave estrangeira para Register. 'unique' para garantir 1-para-1.
}

func (Delivery) TableName() string {
	return "delivery"
}