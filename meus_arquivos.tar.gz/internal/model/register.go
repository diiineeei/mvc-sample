package model

import "time"

type Register struct {
	ID        uint       `gorm:"primaryKey;autoIncrement"`
	Registry  string     `gorm:"type:varchar(255);not null"`
	Path      string     `gorm:"type:varchar(500);not null"`
	CreatedAt time.Time  `gorm:"not null"`
	UpdatedAt *time.Time
	FileID    uint       `gorm:"not null"` // Chave estrangeira para Batch
	ClientID  *uint      // Chave estrangeira para ClientID (pode ser nula)
	Pursuance *string    `gorm:"type:varchar(255)"`
	Client    *ClientID  `gorm:"foreignKey:ClientID"`   // Relação: Register pertence a um Client
	Delivery  *Delivery  `gorm:"foreignKey:RegisterID"` // Relação: Register tem um Delivery
}

func (Register) TableName() string {
	return "register"
}