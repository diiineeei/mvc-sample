package model

// ClientID representa a tabela client_id.
// Recomenda-se renomear a tabela no banco para "clients" para maior clareza.
type ClientID struct {
	ID   uint    `gorm:"primaryKey;autoIncrement"`
	Name *string `gorm:"type:varchar(255)"`
	CPF  *string `gorm:"type:varchar(255)"`
}

func (ClientID) TableName() string {
	return "client_id"
}