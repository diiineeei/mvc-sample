package controller

import (
	"integracao-fornecedor/internal/domain/model"
	"integracao-fornecedor/internal/service"
	"net/http"

	"github.com/gin-gonic/gin"
)

type RegisterController struct {
	service service.IRegisterService
}

func NewRegisterController(s service.IRegisterService) *RegisterController {
	return &RegisterController{service: s}
}

type CreateRegisterRequest struct {
	BatchName    *string `json:"batch_name"`
	BatchID      uint    `json:"batch_id"`
	Registry     string  `json:"registry" binding:"required"`
	Path         string  `json:"path" binding:"required"`
	ClientID     *uint   `json:"client_id"`
	Pursuance    *string `json:"pursuance"`
	PageQuantity *int    `json:"page_quantity"`
	Address      string  `json:"address" binding:"required"`
}

// CreateRegister godoc
// @Summary      Cria um registro de arquivo pdf
// @Description  Cria um novo registro de PDF associado a um lote. Deve ser fornecido `batch_id` ou `batch_name`.
// @Tags         Register
// @Accept       json
// @Produce      json
// @Param        register  body      CreateRegisterRequest  true  "Dados para criação do registro"
// @Success      201      {object}  nil "Registro criado com sucesso"
// @Failure      400      {object}  map[string]string "Erro na requisição"
// @Failure      500      {object}  map[string]string "Erro interno do servidor"
// @Router       /v1/register [post]
func (c *RegisterController) CreateRegister(ctx *gin.Context) {
	var req CreateRegisterRequest
	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	register := &model.Register{
		BatchID:      req.BatchID,
		Registry:     req.Registry,
		Path:         req.Path,
		ClientID:     req.ClientID,
		Pursuance:    req.Pursuance,
		PageQuantity: req.PageQuantity,
	}

	err := c.service.CreateRegister(register, req.Address, req.BatchName)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	ctx.Status(http.StatusCreated)
}
