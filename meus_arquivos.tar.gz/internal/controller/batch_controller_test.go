package controller

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

// MockBatchService é uma implementação mock de IBatchService para testes.
type MockBatchService struct {
	CreateBatchFunc         func(name, batchType string) (uint, error)
	UpdateBatchFunc         func(id uint, data map[string]interface{}) error
	ListApprovedBatchesFunc func() ([]uint, error)
}

func (m *MockBatchService) CreateBatch(name, batchType string) (uint, error) {
	return m.CreateBatchFunc(name, batchType)
}

func (m *MockBatchService) UpdateBatch(id uint, data map[string]interface{}) error {
	return m.UpdateBatchFunc(id, data)
}

func (m *MockBatchService) ListApprovedBatches() ([]uint, error) {
	return m.ListApprovedBatchesFunc()
}

func setupRouter() *gin.Engine {
	gin.SetMode(gin.TestMode)
	r := gin.Default()
	return r
}

func TestBatchController_CreateBatch(t *testing.T) {
	t.Run("Success", func(t *testing.T) {
		mockService := &MockBatchService{
			CreateBatchFunc: func(name, batchType string) (uint, error) {
				return 1, nil
			},
		}
		controller := NewBatchController(mockService)

		r := setupRouter()
		r.POST("/v1/batch", controller.CreateBatch)

		payload := `{"batch_name": "test", "type": "test_type"}`
		req, _ := http.NewRequest(http.MethodPost, "/v1/batch", bytes.NewBufferString(payload))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusCreated, w.Code)
		assert.JSONEq(t, `{"batch_id": 1}`, w.Body.String())
	})

	t.Run("Bad Request", func(t *testing.T) {
		controller := NewBatchController(&MockBatchService{})
		r := setupRouter()
		r.POST("/v1/batch", controller.CreateBatch)

		payload := `{"batch_name": "test"}` // Missing type
		req, _ := http.NewRequest(http.MethodPost, "/v1/batch", bytes.NewBufferString(payload))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusBadRequest, w.Code)
	})
}

func TestBatchController_UpdateBatch(t *testing.T) {
	t.Run("Success", func(t *testing.T) {
		mockService := &MockBatchService{
			UpdateBatchFunc: func(id uint, data map[string]interface{}) error {
				return nil
			},
		}
		controller := NewBatchController(mockService)

		r := setupRouter()
		r.PATCH("/v1/batch/:id", controller.UpdateBatch)

		payload := `{"status": "approved"}`
		req, _ := http.NewRequest(http.MethodPatch, "/v1/batch/1", bytes.NewBufferString(payload))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.JSONEq(t, `{"batch_id": 1}`, w.Body.String())
	})

	t.Run("Invalid ID", func(t *testing.T) {
		controller := NewBatchController(&MockBatchService{})
		r := setupRouter()
		r.PATCH("/v1/batch/:id", controller.UpdateBatch)

		req, _ := http.NewRequest(http.MethodPatch, "/v1/batch/abc", nil)

		w := httptest.NewRecorder()
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error": "invalid id"}`, w.Body.String())
	})
}

func TestBatchController_ListApprovedBatches(t *testing.T) {
	mockService := &MockBatchService{
		ListApprovedBatchesFunc: func() ([]uint, error) {
			return []uint{1, 2}, nil
		},
	}
	controller := NewBatchController(mockService)

	r := setupRouter()
	r.GET("/v1/batch/list", controller.ListApprovedBatches)

	req, _ := http.NewRequest(http.MethodGet, "/v1/batch/list", nil)

	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusOK, w.Code)
	assert.JSONEq(t, `{"batch_ids": [1, 2]}`, w.Body.String())
}
