package controller

import (
	"bytes"
	"errors"
	"integracao-fornecedor/internal/domain/model"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
)

// MockRegisterService é uma implementação mock de IRegisterService para testes.
type MockRegisterService struct {
	CreateRegisterFunc func(data *model.Register, address string, batchName *string) error
}

func (m *MockRegisterService) CreateRegister(data *model.Register, address string, batchName *string) error {
	return m.CreateRegisterFunc(data, address, batchName)
}

func TestRegisterController_CreateRegister(t *testing.T) {
	t.Run("Success", func(t *testing.T) {
		mockService := &MockRegisterService{
			CreateRegisterFunc: func(data *model.Register, address string, batchName *string) error {
				return nil
			},
		}
		controller := NewRegisterController(mockService)

		r := setupRouter()
		r.POST("/v1/register", controller.CreateRegister)

		payload := `{"batch_id": 1, "registry": "123", "path": "/path", "address": "addr"}`
		req, _ := http.NewRequest(http.MethodPost, "/v1/register", bytes.NewBufferString(payload))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusCreated, w.Code)
	})

	t.Run("Bad Request", func(t *testing.T) {
		controller := NewRegisterController(&MockRegisterService{})
		r := setupRouter()
		r.POST("/v1/register", controller.CreateRegister)

		payload := `{"batch_id": 1}` // Missing required fields
		req, _ := http.NewRequest(http.MethodPost, "/v1/register", bytes.NewBufferString(payload))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("Internal Server Error", func(t *testing.T) {
		mockService := &MockRegisterService{
			CreateRegisterFunc: func(data *model.Register, address string, batchName *string) error {
				return errors.New("service error")
			},
		}
		controller := NewRegisterController(mockService)

		r := setupRouter()
		r.POST("/v1/register", controller.CreateRegister)

		payload := `{"batch_id": 1, "registry": "123", "path": "/path", "address": "addr"}`
		req, _ := http.NewRequest(http.MethodPost, "/v1/register", bytes.NewBufferString(payload))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.JSONEq(t, `{"error": "service error"}`, w.Body.String())
	})
}
