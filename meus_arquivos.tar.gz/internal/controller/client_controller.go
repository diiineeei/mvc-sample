package controller

import (
	"integracao-fornecedor/internal/service"
	"net/http"

	"github.com/gin-gonic/gin"
)

type ClientController struct {
	service service.IClientService
}

func NewClientController(s service.IClientService) *ClientController {
	return &ClientController{service: s}
}

type CreateClientRequest struct {
	Name string `json:"name" binding:"required"`
	CPF  string `json:"cpf" binding:"required"`
}

// CreateClient godoc
// @Summary      Cria uma entidade cliente
// @Description  Cria um novo cliente ou atualiza um cliente existente com base no CPF.
// @Tags         Client
// @Accept       json
// @Produce      json
// @Param        client  body      CreateClientRequest  true  "Dados para criação ou atualização do cliente"
// @Success      201  {object}  map[string]uint   "Cliente criado/atualizado com sucesso"
// @Failure      400  {object}  map[string]string "Erro na requisição"
// @Failure      500  {object}  map[string]string "Erro interno do servidor"
// @Router       /v1/client [post]
func (c *ClientController) CreateClient(ctx *gin.Context) {
	var req CreateClientRequest
	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	clientID, err := c.service.CreateOrUpdateClient(req.Name, req.CPF)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	ctx.JSON(http.StatusCreated, gin.H{"client_id": clientID})
}
