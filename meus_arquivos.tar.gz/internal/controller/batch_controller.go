package controller

import (
	"integracao-fornecedor/internal/service"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

type BatchController struct {
	service service.IBatchService
}

func NewBatchController(s service.IBatchService) *BatchController {
	return &BatchController{service: s}
}

type CreateBatchRequest struct {
	BatchName string `json:"batch_name" binding:"required"`
	Type      string `json:"type" binding:"required"`
}

// CreateBatch godoc
// @Summary      Cria um registro de arquivo
// @Description  Cria um novo lote de arquivos com o nome e tipo especificados, com status inicial 'pending'.
// @Tags         Batch
// @Accept       json
// @Produce      json
// @Param        batch  body      CreateBatchRequest  true  "Dados para criação do lote"
// @Success      201  {object}  map[string]uint   "Lote criado com sucesso"
// @Failure      400  {object}  map[string]string "Erro na requisição"
// @Failure      500  {object}  map[string]string "Erro interno do servidor"
// @Router       /v1/batch [post]
func (c *BatchController) CreateBatch(ctx *gin.Context) {
	var req CreateBatchRequest
	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	batchID, err := c.service.CreateBatch(req.BatchName, req.Type)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	ctx.JSON(http.StatusCreated, gin.H{"batch_id": batchID})
}

// UpdateBatch godoc
// @Summary      Atualiza um registro de arquivo
// @Description  Atualiza o status e outros dados de um lote existente. A descrição é obrigatória para os status 'reproved' e 'reprocess'.
// @Tags         Batch
// @Accept       json
// @Produce      json
// @Param        id   path      int                  true  "ID do Lote"
// @Param        data body      map[string]interface{} true  "Dados para atualização"
// @Success      200  {object}  map[string]uint64  "Lote atualizado com sucesso"
// @Failure      400  {object}  map[string]string  "ID inválido ou erro na requisição"
// @Failure      500  {object}  map[string]string  "Erro interno do servidor"
// @Router       /v1/batch/{id} [patch]
func (c *BatchController) UpdateBatch(ctx *gin.Context) {
	idStr := ctx.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 64)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	var data map[string]interface{}
	if err := ctx.ShouldBindJSON(&data); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if err := c.service.UpdateBatch(uint(id), data); err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{"batch_id": id})
}

// ListApprovedBatches godoc
// @Summary      Buscar arquivos disponiveis para impressao
// @Description  Retorna uma lista de IDs de lotes que estão com o status 'approved'.
// @Tags         Batch
// @Produce      json
// @Success      200  {object}  map[string][]uint "Lista de IDs de lotes aprovados"
// @Failure      500  {object}  map[string]string "Erro interno do servidor"
// @Router       /v1/batch/list [get]
func (c *BatchController) ListApprovedBatches(ctx *gin.Context) {
	batchIDs, err := c.service.ListApprovedBatches()
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{"batch_ids": batchIDs})
}
