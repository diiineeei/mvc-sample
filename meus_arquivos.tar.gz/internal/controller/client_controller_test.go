package controller

import (
	"bytes"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
)

// MockClientService é uma implementação mock de IClientService para testes.
type MockClientService struct {
	CreateOrUpdateClientFunc func(name, cpf string) (uint, error)
}

func (m *MockClientService) CreateOrUpdateClient(name, cpf string) (uint, error) {
	return m.CreateOrUpdateClientFunc(name, cpf)
}

func TestClientController_CreateClient(t *testing.T) {
	t.Run("Success", func(t *testing.T) {
		mockService := &MockClientService{
			CreateOrUpdateClientFunc: func(name, cpf string) (uint, error) {
				return 1, nil
			},
		}
		controller := NewClientController(mockService)

		r := setupRouter()
		r.POST("/v1/client", controller.CreateClient)

		payload := `{"name": "Test", "cpf": "12345"}`
		req, _ := http.NewRequest(http.MethodPost, "/v1/client", bytes.NewBufferString(payload))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusCreated, w.Code)
		assert.JSONEq(t, `{"client_id": 1}`, w.Body.String())
	})

	t.Run("Bad Request", func(t *testing.T) {
		controller := NewClientController(&MockClientService{})
		r := setupRouter()
		r.POST("/v1/client", controller.CreateClient)

		payload := `{"name": "Test"}` // Missing CPF
		req, _ := http.NewRequest(http.MethodPost, "/v1/client", bytes.NewBufferString(payload))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("Internal Server Error", func(t *testing.T) {
		mockService := &MockClientService{
			CreateOrUpdateClientFunc: func(name, cpf string) (uint, error) {
				return 0, errors.New("db error")
			},
		}
		controller := NewClientController(mockService)

		r := setupRouter()
		r.POST("/v1/client", controller.CreateClient)

		payload := `{"name": "Test", "cpf": "12345"}`
		req, _ := http.NewRequest(http.MethodPost, "/v1/client", bytes.NewBufferString(payload))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.JSONEq(t, `{"error": "db error"}`, w.Body.String())
	})
}
