package repository

import (
	"integracao-fornecedor/internal/domain/model"

	"gorm.io/gorm"
)

type IRegisterRepository interface {
	Create(register *model.Register) error
}

type RegisterRepository struct {
	db *gorm.DB
}

func NewRegisterRepository(db *gorm.DB) *RegisterRepository {
	return &RegisterRepository{db: db}
}

func (r *RegisterRepository) Create(register *model.Register) error {
	return r.db.Create(register).Error
}
