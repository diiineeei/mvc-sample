package repository

import (
	"integracao-fornecedor/internal/domain/model"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

type IClientRepository interface {
	CreateOrUpdate(client *model.Client) (uint, error)
}

type ClientRepository struct {
	db *gorm.DB
}

func NewClientRepository(db *gorm.DB) *ClientRepository {
	return &ClientRepository{db: db}
}

func (r *ClientRepository) CreateOrUpdate(client *model.Client) (uint, error) {
	err := r.db.Clauses(clause.OnConflict{
		Columns:   []clause.Column{{Name: "cpf"}},
		DoUpdates: clause.AssignmentColumns([]string{"name"}),
	}).Create(client).Error

	if err != nil {
		return 0, err
	}
	return client.ID, nil
}
