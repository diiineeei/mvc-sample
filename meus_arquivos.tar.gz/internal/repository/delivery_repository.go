package repository

import (
	"integracao-fornecedor/internal/domain/model"
	"gorm.io/gorm"
)

type IDeliveryRepository interface {
	Create(delivery *model.Delivery) error
}

type DeliveryRepository struct {
	db *gorm.DB
}

func NewDeliveryRepository(db *gorm.DB) *DeliveryRepository {
	return &DeliveryRepository{db: db}
}

func (r *DeliveryRepository) Create(delivery *model.Delivery) error {
	return r.db.Create(delivery).Error
}
