package repository

import (
	"integracao-fornecedor/internal/domain/model"

	"gorm.io/gorm"
)

type IBatchRepository interface {
	Create(batch *model.Batch) (uint, error)
	Update(id uint, batch map[string]interface{}) error
	FindApproved() ([]uint, error)
	FindByName(name string) (*model.Batch, error)
	FindByID(id uint) (*model.Batch, error)
}

type BatchRepository struct {
	db *gorm.DB
}

func NewBatchRepository(db *gorm.DB) *BatchRepository {
	return &BatchRepository{db: db}
}

func (r *BatchRepository) Create(batch *model.Batch) (uint, error) {
	err := r.db.Create(batch).Error
	if err != nil {
		return 0, err
	}
	return batch.BatchID, nil
}

func (r *BatchRepository) Update(id uint, batch map[string]interface{}) error {
	return r.db.Model(&model.Batch{}).Where("batch_id = ?", id).Updates(batch).Error
}

func (r *BatchRepository) FindApproved() ([]uint, error) {
	var batchIDs []uint
	err := r.db.Model(&model.Batch{}).Where("status = ?", "approved").Pluck("batch_id", &batchIDs).Error
	return batchIDs, err
}

func (r *BatchRepository) FindByName(name string) (*model.Batch, error) {
	var batch model.Batch
	err := r.db.Where("name = ?", name).First(&batch).Error
	if err != nil {
		return nil, err
	}
	return &batch, nil
}

func (r *BatchRepository) FindByID(id uint) (*model.Batch, error) {
	var batch model.Batch
	err := r.db.Where("batch_id = ?", id).First(&batch).Error
	if err != nil {
		return nil, err
	}
	return &batch, nil
}
