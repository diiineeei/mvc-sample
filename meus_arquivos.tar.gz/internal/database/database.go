package database

import (
	"fmt"
	"integracao-fornecedor/internal/config"
	"integracao-fornecedor/internal/model"
	"log/slog"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func InitDatabase(cfg *config.Config) (*gorm.DB, error) {
	dsn := fmt.Sprintf("host=%s user=%s password=%s dbname=%s port=%s sslmode=disable TimeZone=America/Sao_Paulo",
		cfg.DBHost,
		cfg.DBUser,
		cfg.DBPassword,
		cfg.DBName,
		cfg.DBPort,
	)

	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		return nil, fmt.Errorf("falha ao conectar ao banco de dados: %w", err)
	}

	slog.Info("Migrando o banco de dados...")
	// AutoMigrate irá criar/atualizar as tabelas com base nos seus modelos GORM.
	err = db.AutoMigrate(&model.Batch{}, &model.Register{}, &model.ClientID{}, &model.Delivery{})
	if err != nil {
		return nil, fmt.Errorf("falha ao migrar o banco de dados: %w", err)
	}

	slog.Info("Migração do banco de dados concluída com sucesso.")
	return db, nil
}