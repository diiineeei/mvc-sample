package router

import (
	"integracao-fornecedor/internal/controller"
	"integracao-fornecedor/internal/repository"
	"integracao-fornecedor/internal/service"
	"log/slog"
	"time"

	"github.com/gin-gonic/gin"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
	"gorm.io/gorm"
)

func SlogMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()

		c.Next()

		latency := time.Since(start)
		status := c.Writer.Status()

		slog.Info("requisição recebida",
			"status", status,
			"metodo", c.Request.Method,
			"caminho", c.Request.URL.Path,
			"ip", c.ClientIP(),
			"latencia", latency.String(),
			"user_agent", c.Request.UserAgent(),
		)
	}
}

func SetupRouter(db *gorm.DB) *gin.Engine {
	r := gin.New()
	r.Use(gin.Recovery())
	r.Use(SlogMiddleware())

	r.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))

	batchRepo := repository.NewBatchRepository(db)
	registerRepo := repository.NewRegisterRepository(db)
	clientRepo := repository.NewClientRepository(db)
	deliveryRepo := repository.NewDeliveryRepository(db)

	batchSvc := service.NewBatchService(batchRepo)
	registerSvc := service.NewRegisterService(registerRepo, batchRepo, deliveryRepo)
	clientSvc := service.NewClientService(clientRepo)

	batchCtrl := controller.NewBatchController(batchSvc)
	registerCtrl := controller.NewRegisterController(registerSvc)
	clientCtrl := controller.NewClientController(clientSvc)

	v1 := r.Group("/v1")
	{
		batchRoutes := v1.Group("/batch")
		{
			batchRoutes.POST("", batchCtrl.CreateBatch)
			batchRoutes.PATCH("/:id", batchCtrl.UpdateBatch)
			batchRoutes.GET("/list", batchCtrl.ListApprovedBatches)
		}

		v1.POST("/register", registerCtrl.CreateRegister)

		v1.POST("/client", clientCtrl.CreateClient)
	}

	return r
}
