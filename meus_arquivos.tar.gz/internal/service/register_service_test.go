package service

import (
	"errors"
	"integracao-fornecedor/internal/domain/model"
	"testing"

	"github.com/stretchr/testify/assert"
)

// MockRegisterRepository é uma implementação mock de IRegisterRepository para testes.
type MockRegisterRepository struct {
	CreateFunc func(register *model.Register) error
}

func (m *MockRegisterRepository) Create(register *model.Register) error {
	return m.CreateFunc(register)
}

// MockDeliveryRepository é uma implementação mock de IDeliveryRepository para testes.
type MockDeliveryRepository struct {
	CreateFunc func(delivery *model.Delivery) error
}

func (m *MockDeliveryRepository) Create(delivery *model.Delivery) error {
	return m.CreateFunc(delivery)
}

func TestRegisterService_CreateRegister(t *testing.T) {
	batchName := "test_batch"

	t.Run("Success with batch_id", func(t *testing.T) {
		mockBatchRepo := &MockBatchRepository{
			FindByIDFunc: func(id uint) (*model.Batch, error) {
				return &model.Batch{BatchID: 1}, nil
			},
		}
		mockRegisterRepo := &MockRegisterRepository{
			CreateFunc: func(register *model.Register) error {
				register.RegisterID = 1 // Simula a atribuição do ID pelo banco
				return nil
			},
		}
		mockDeliveryRepo := &MockDeliveryRepository{
			CreateFunc: func(delivery *model.Delivery) error {
				assert.Equal(t, uint(1), delivery.RegisterID)
				assert.Equal(t, "test_address", delivery.Address)
				return nil
			},
		}

		registerService := NewRegisterService(mockRegisterRepo, mockBatchRepo, mockDeliveryRepo)
		registerData := &model.Register{BatchID: 1}
		err := registerService.CreateRegister(registerData, "test_address", nil)

		assert.NoError(t, err)
	})

	t.Run("Success with batch_name", func(t *testing.T) {
		mockBatchRepo := &MockBatchRepository{
			FindByNameFunc: func(name string) (*model.Batch, error) {
				return &model.Batch{BatchID: 2}, nil
			},
		}
		mockRegisterRepo := &MockRegisterRepository{
			CreateFunc: func(register *model.Register) error {
				assert.Equal(t, uint(2), register.BatchID)
				return nil
			},
		}
		mockDeliveryRepo := &MockDeliveryRepository{
			CreateFunc: func(delivery *model.Delivery) error { return nil },
		}

		registerService := NewRegisterService(mockRegisterRepo, mockBatchRepo, mockDeliveryRepo)
		registerData := &model.Register{}
		err := registerService.CreateRegister(registerData, "test_address", &batchName)

		assert.NoError(t, err)
	})

	t.Run("Error - batch_id not found", func(t *testing.T) {
		mockBatchRepo := &MockBatchRepository{
			FindByIDFunc: func(id uint) (*model.Batch, error) {
				return nil, errors.New("not found")
			},
		}

		registerService := NewRegisterService(nil, mockBatchRepo, nil)
		registerData := &model.Register{BatchID: 99}
		err := registerService.CreateRegister(registerData, "test_address", nil)

		assert.Error(t, err)
		assert.Equal(t, "batch_id not found", err.Error())
	})

	t.Run("Error - no batch_id or batch_name", func(t *testing.T) {
		registerService := NewRegisterService(nil, nil, nil)
		registerData := &model.Register{}
		err := registerService.CreateRegister(registerData, "test_address", nil)

		assert.Error(t, err)
		assert.Equal(t, "either batch_id or batch_name must be provided", err.Error())
	})
}
