package service

import (
	"integracao-fornecedor/internal/domain/model"
	"testing"

	"github.com/stretchr/testify/assert"
)

// MockClientRepository é uma implementação mock de IClientRepository para testes.
type MockClientRepository struct {
	CreateOrUpdateFunc func(client *model.Client) (uint, error)
}

func (m *MockClientRepository) CreateOrUpdate(client *model.Client) (uint, error) {
	return m.CreateOrUpdateFunc(client)
}

func TestClientService_CreateOrUpdateClient(t *testing.T) {
	mockRepo := &MockClientRepository{
		CreateOrUpdateFunc: func(client *model.Client) (uint, error) {
			assert.Equal(t, "Test Client", client.Name)
			assert.Equal(t, "12345678900", client.CPF)
			return 1, nil
		},
	}

	clientService := NewClientService(mockRepo)
	clientID, err := clientService.CreateOrUpdateClient("Test Client", "12345678900")

	assert.NoError(t, err)
	assert.Equal(t, uint(1), clientID)
}
