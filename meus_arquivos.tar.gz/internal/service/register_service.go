package service

import (
	"errors"
	"integracao-fornecedor/internal/domain/model"
	"integracao-fornecedor/internal/repository"
	"time"
)

type IRegisterService interface {
	CreateRegister(data *model.Register, address string, batchName *string) error
}

type RegisterService struct {
	registerRepo repository.IRegisterRepository
	batchRepo    repository.IBatchRepository
	deliveryRepo repository.IDeliveryRepository
}

func NewRegisterService(registerRepo repository.IRegisterRepository, batchRepo repository.IBatchRepository, deliveryRepo repository.IDeliveryRepository) *RegisterService {
	return &RegisterService{
		registerRepo: registerRepo,
		batchRepo:    batchRepo,
		deliveryRepo: deliveryRepo,
	}
}

func (s *RegisterService) CreateRegister(data *model.Register, address string, batchName *string) error {
	var finalBatchID uint

	if data.BatchID != 0 {
		finalBatchID = data.BatchID
		_, err := s.batchRepo.FindByID(finalBatchID)
		if err != nil {
			return errors.New("batch_id not found")
		}
	} else if batchName != nil && *batchName != "" {
		batch, err := s.batchRepo.FindByName(*batchName)
		if err != nil {
			return errors.New("batch_name not found")
		}
		finalBatchID = batch.BatchID
	} else {
		return errors.New("either batch_id or batch_name must be provided")
	}

	register := &model.Register{
		Registry:     data.Registry,
		Path:         data.Path,
		CreatedAt:    time.Now(),
		BatchID:      finalBatchID,
		ClientID:     data.ClientID,
		Pursuance:    data.Pursuance,
		PageQuantity: data.PageQuantity,
	}

	err := s.registerRepo.Create(register)
	if err != nil {
		return err
	}

	delivery := &model.Delivery{
		Address:    address,
		RegisterID: register.RegisterID,
	}

	return s.deliveryRepo.Create(delivery)
}
