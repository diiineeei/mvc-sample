package service

import (
	"errors"
	"integracao-fornecedor/internal/domain/model"
	"integracao-fornecedor/internal/repository"
	"time"
)

type IBatchService interface {
	CreateBatch(name, batchType string) (uint, error)
	UpdateBatch(id uint, data map[string]interface{}) error
	ListApprovedBatches() ([]uint, error)
}

type BatchService struct {
	repo repository.IBatchRepository
}

func NewBatchService(r repository.IBatchRepository) *BatchService {
	return &BatchService{repo: r}
}

func (s *BatchService) CreateBatch(name, batchType string) (uint, error) {
	batch := &model.Batch{
		Name:      name,
		Type:      batchType,
		Status:    "pending",
		CreatedAt: time.Now(),
	}
	return s.repo.Create(batch)
}

func (s *BatchService) UpdateBatch(id uint, data map[string]interface{}) error {
	status, ok := data["status"].(string)
	if ok {
		description, hasDescription := data["description"].(string)
		if (status == "reproved" || status == "reprocess") && (!hasDescription || description == "") {
			return errors.New("description is required for status 'reproved' or 'reprocess'")
		}
		if status == "printing" {
			if _, ok := data["date_printing"]; !ok {
				return errors.New("date_printing is required for status 'printing'")
			}
		}
		if status == "in_release" {
			if _, ok := data["release_date"]; !ok {
				return errors.New("release_date is required for status 'in_release'")
			}
		}
		if status == "en_route" {
			if _, ok := data["shipping_date"]; !ok {
				return errors.New("shipping_date is required for status 'en_route'")
			}
		}
	}

	return s.repo.Update(id, data)
}

func (s *BatchService) ListApprovedBatches() ([]uint, error) {
	return s.repo.FindApproved()
}
