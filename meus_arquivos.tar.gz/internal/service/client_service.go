package service

import (
	"integracao-fornecedor/internal/domain/model"
	"integracao-fornecedor/internal/repository"
)

type IClientService interface {
	CreateOrUpdateClient(name, cpf string) (uint, error)
}

type ClientService struct {
	repo repository.IClientRepository
}

func NewClientService(r repository.IClientRepository) *ClientService {
	return &ClientService{repo: r}
}

func (s *ClientService) CreateOrUpdateClient(name, cpf string) (uint, error) {
	client := &model.Client{
		Name: name,
		CPF:  cpf,
	}
	return s.repo.CreateOrUpdate(client)
}
