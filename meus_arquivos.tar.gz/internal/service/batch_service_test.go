package service

import (
	"integracao-fornecedor/internal/domain/model"
	"testing"

	"github.com/stretchr/testify/assert"
)

// MockBatchRepository é uma implementação mock de IBatchRepository para testes.
type MockBatchRepository struct {
	CreateFunc       func(batch *model.Batch) (uint, error)
	UpdateFunc       func(id uint, batch map[string]interface{}) error
	FindApprovedFunc func() ([]uint, error)
	FindByNameFunc   func(name string) (*model.Batch, error)
	FindByIDFunc     func(id uint) (*model.Batch, error)
}

func (m *MockBatchRepository) Create(batch *model.Batch) (uint, error) {
	return m.CreateFunc(batch)
}

func (m *MockBatchRepository) Update(id uint, batch map[string]interface{}) error {
	return m.UpdateFunc(id, batch)
}

func (m *MockBatchRepository) FindApproved() ([]uint, error) {
	return m.FindApprovedFunc()
}

func (m *MockBatchRepository) FindByName(name string) (*model.Batch, error) {
	return m.FindByNameFunc(name)
}

func (m *MockBatchRepository) FindByID(id uint) (*model.Batch, error) {
	return m.FindByIDFunc(id)
}

func TestBatchService_CreateBatch(t *testing.T) {
	mockRepo := &MockBatchRepository{
		CreateFunc: func(batch *model.Batch) (uint, error) {
			assert.Equal(t, "test_batch", batch.Name)
			assert.Equal(t, "test_type", batch.Type)
			assert.Equal(t, "pending", batch.Status)
			return 1, nil
		},
	}

	batchService := NewBatchService(mockRepo)
	batchID, err := batchService.CreateBatch("test_batch", "test_type")

	assert.NoError(t, err)
	assert.Equal(t, uint(1), batchID)
}

func TestBatchService_UpdateBatch(t *testing.T) {
	t.Run("Success", func(t *testing.T) {
		mockRepo := &MockBatchRepository{
			UpdateFunc: func(id uint, data map[string]interface{}) error {
				assert.Equal(t, uint(1), id)
				return nil
			},
		}
		batchService := NewBatchService(mockRepo)
		data := map[string]interface{}{"status": "approved"}
		err := batchService.UpdateBatch(1, data)
		assert.NoError(t, err)
	})

	t.Run("Error - Reproved without description", func(t *testing.T) {
		batchService := NewBatchService(&MockBatchRepository{})
		data := map[string]interface{}{"status": "reproved"}
		err := batchService.UpdateBatch(1, data)
		assert.Error(t, err)
		assert.Equal(t, "description is required for status 'reproved' or 'reprocess'", err.Error())
	})

	t.Run("Error - Printing without date_printing", func(t *testing.T) {
		batchService := NewBatchService(&MockBatchRepository{})
		data := map[string]interface{}{"status": "printing"}
		err := batchService.UpdateBatch(1, data)
		assert.Error(t, err)
		assert.Equal(t, "date_printing is required for status 'printing'", err.Error())
	})
}

func TestBatchService_ListApprovedBatches(t *testing.T) {
	mockRepo := &MockBatchRepository{
		FindApprovedFunc: func() ([]uint, error) {
			return []uint{1, 2, 3}, nil
		},
	}

	batchService := NewBatchService(mockRepo)
	batchIDs, err := batchService.ListApprovedBatches()

	assert.NoError(t, err)
	assert.Equal(t, []uint{1, 2, 3}, batchIDs)
}
