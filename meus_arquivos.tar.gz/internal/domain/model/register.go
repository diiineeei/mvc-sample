package model

import "time"

type Register struct {
	RegisterID   uint `gorm:"primaryKey;autoIncrement"`
	Registry     string
	Path         string
	CreatedAt    time.Time
	UpdatedAt    *time.Time
	BatchID      uint
	ClientID     *uint
	Pursuance    *string
	PageQuantity *int
	Delivery     Delivery `gorm:"foreignKey:RegisterID"`
}
