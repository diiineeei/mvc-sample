package model

type Client struct {
	ID   uint `gorm:"primaryKey;autoIncrement" json:"id"`
	Name string `json:"name"`
	CPF  string `json:"cpf"`
}
