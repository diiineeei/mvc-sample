package model

import "time"

type Batch struct {
	BatchID      uint `gorm:"primaryKey;autoIncrement"`
	Name         string
	ExternalID   string
	CreatedAt    time.Time
	Type         string
	UpdatedAt    *time.Time
	Status       string
	DeliveredAt  *time.Time
	Description  *string
	DateCIF      *time.Time
	DatePrinting *time.Time
	ReleaseDate  *time.Time
	ShippingDate *time.Time
	Registers    []Register `gorm:"foreignKey:BatchID"`
}
