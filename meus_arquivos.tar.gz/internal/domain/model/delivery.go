package model

type Delivery struct {
	ID         uint   `gorm:"primaryKey;autoIncrement"`
	Address    string `json:"address"`
	RegisterID uint   `json:"register_id"`
}
